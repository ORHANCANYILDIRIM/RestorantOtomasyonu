
package Yardımcı;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class IdSayac {

 
    
    public static int idSayac() throws IOException {
        int IdSayac = 0;
        FileReader fileReader = new FileReader("C:\\Users\\zafer\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Kullanici.txt");
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line = bufferedReader.readLine();
        while (line != null) {
            IdSayac += 1;
            line = bufferedReader.readLine();
        }
        return IdSayac ;

    }
    public static int idSayacMutfak() throws IOException {
        int IdSayac = 0;
        FileReader fileReader = new FileReader("C:\\Users\\zafer\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Menu.txt");
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line = bufferedReader.readLine();
        while (line != null) {
            IdSayac += 1;
            line = bufferedReader.readLine();
        }
        return IdSayac ;

    }
    
    public static int idSayacMasa() throws IOException {
        int IdSayac = 0;
        FileReader fileReader = new FileReader("C:\\Users\\zafer\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Masa.txt");
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line = bufferedReader.readLine();
        while (line != null) {
            IdSayac += 1;
            line = bufferedReader.readLine();
        }
        return IdSayac ;

    }
}
