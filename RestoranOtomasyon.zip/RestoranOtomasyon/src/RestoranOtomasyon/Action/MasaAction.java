package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.MasaController;
import RestoranOtomasyon.Gui.MasaGUI;
import RestoranOtomasyon.Gui.SuperAdminGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MasaAction implements ActionListener{
    private MasaGUI masa;
    private MasaController masaC;

    public MasaAction(MasaGUI masa) {
        this.masa = masa;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==masa.getGeriDon()){
            new SuperAdminGUI();
            masa.dispose();
        }
        if(e.getSource()==masa.getEkle()){
            Object Doluluk=masa.getDolulukF().getSelectedItem();
            try {
                getMasaC().create((String) Doluluk);
                masa.MasaModelGuncelle();
            } catch (IOException ex) {
                Logger.getLogger(MasaAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(e.getSource()==masa.getÇıkart()){
              String Id=masa.getCikarmaID().getText();
            try {
                getMasaC().sil(Id);
                masa.MasaModelGuncelle();
            } catch (IOException ex) {
                Logger.getLogger(MasaAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public MasaController getMasaC() {
        if(masaC==null){
            masaC=new MasaController();
        }
        return masaC;
    }

    
    
}
