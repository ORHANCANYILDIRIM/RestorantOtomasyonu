package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.KullaniciController;
import RestoranOtomasyon.Gui.KayıtOlGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class KayıtOlAction implements ActionListener{
    private KayıtOlGUI kayıt;
    private KullaniciController Kc;

    public KayıtOlAction(KayıtOlGUI kayıt) {
        this.kayıt = kayıt;
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
         
    if(e.getSource() == kayıt.getKayıtOl()){
       String IsımSoyisim= kayıt.getIsımSoyısımF().getText();
       String Parola= kayıt.getParolaF().getText();
       String ParolaYeni= kayıt.getParolaYeniF().getText();
       String KullaniciAdi= kayıt.getKullaniciAdiF().getText();
       
       if(IsımSoyisim.length()==0 || Parola.length()==0 || ParolaYeni.length()==0 || KullaniciAdi.length()==0){
           JOptionPane.showMessageDialog(null, "Lütfen bos alanlari doldurunuz");
       }else if(Parola.equals(ParolaYeni)){
           try {
               getKc().create(IsımSoyisim,KullaniciAdi,Parola);
               
           } catch (IOException ex) {
               Logger.getLogger(KayıtOlAction.class.getName()).log(Level.SEVERE, null, ex);
           }  
       }
       else{
           JOptionPane.showMessageDialog(null, "Girdiginiz parolalar eslesmemektedir.");
       }
       }    
    }
        

    
    public KullaniciController getKc() {
        if(this.Kc==null){
            Kc=new KullaniciController();
        }
        return Kc;
    }
    
}
