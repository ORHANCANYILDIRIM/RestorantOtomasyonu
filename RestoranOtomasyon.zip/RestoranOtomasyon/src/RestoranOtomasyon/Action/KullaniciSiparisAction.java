package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.MutfakController;
import RestoranOtomasyon.Gui.KullaniciGUI;
import RestoranOtomasyon.Gui.KullaniciSiparisGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KullaniciSiparisAction implements ActionListener {
    private KullaniciSiparisGUI ksiparis;
    private MutfakController Mc;

    public KullaniciSiparisAction(KullaniciSiparisGUI ksiparis) {
        this.ksiparis = ksiparis;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==ksiparis.getEkle()){
            
            String Yemekadi=ksiparis.getYemekAdiF().getText();
            try {
                if(Mc.checkyemek(Yemekadi)==true){
                    
                }
            } catch (IOException ex) {
                Logger.getLogger(KullaniciSiparisAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(e.getSource()==ksiparis.getCıkıs()){
            new KullaniciGUI();
            ksiparis.dispose();
        }
    }

    public MutfakController getMc() {
        if(Mc==null){
            Mc=new MutfakController();
        }
        return Mc;
    }

    public void setMc(MutfakController Mc) {
        this.Mc = Mc;
    }

}
