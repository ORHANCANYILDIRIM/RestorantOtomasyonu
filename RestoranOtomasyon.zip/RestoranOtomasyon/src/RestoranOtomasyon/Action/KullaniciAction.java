
package RestoranOtomasyon.Action;

import RestoranOtomasyon.Gui.KullaniciGUI;
import RestoranOtomasyon.Gui.KullaniciSiparisGUI;
import RestoranOtomasyon.Gui.SecimGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KullaniciAction implements ActionListener{
    private KullaniciGUI kullanici;

    public KullaniciAction(KullaniciGUI kullanici) {
        this.kullanici = kullanici;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==kullanici.getSiparisver()){
            try {
                new KullaniciSiparisGUI();
            } catch (IOException ex) {
                Logger.getLogger(KullaniciAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            kullanici.dispose();
        }
        if(e.getSource()==kullanici.getCikis()){
            new SecimGUI();
            kullanici.dispose();
        }
    }
    
    
}
