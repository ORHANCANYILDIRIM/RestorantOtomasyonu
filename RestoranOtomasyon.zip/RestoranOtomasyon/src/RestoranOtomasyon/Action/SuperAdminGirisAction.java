
package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.SuperAdminController;
import RestoranOtomasyon.Gui.SuperAdminGUI;
import RestoranOtomasyon.Gui.SuperAdminGirisGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class SuperAdminGirisAction implements ActionListener{
    private SuperAdminGirisGUI giris;
    private SuperAdminController Ac;
    
    public SuperAdminGirisAction(SuperAdminGirisGUI giris) {
        this.giris=giris;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == giris.getAGiris()){
           String KullanıcıAdı=giris.getAdminAdiF().getText();
           String Parola=giris.getAdminSifreF().getText();
           SuperAdminController SA=new SuperAdminController();
           try {
               if(SA.checkUser(KullanıcıAdı, Parola) == true){
                  new SuperAdminGUI();
                  giris.dispose();
               }
               else{
                   JOptionPane.showMessageDialog(null, "Girdiginiz bilgiler hatalidir!");
               }
           } catch (IOException ex) {
               Logger.getLogger(KullaniciGirisAction.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
       if(e.getSource()==giris.getACıkıs()){
           JOptionPane.showMessageDialog(null, "Cikis yapilmistir!");
           giris.dispose();
       }
       
    }
    
    
    
}
