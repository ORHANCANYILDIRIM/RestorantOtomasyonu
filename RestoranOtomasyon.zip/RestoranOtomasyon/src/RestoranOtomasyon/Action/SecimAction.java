package RestoranOtomasyon.Action;

import RestoranOtomasyon.Gui.SuperAdminGirisGUI;
import RestoranOtomasyon.Gui.KullaniciGirisGUI;
import RestoranOtomasyon.Gui.SecimGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SecimAction implements ActionListener{
    private SecimGUI secim;

    public SecimAction(SecimGUI secim) {
        this.secim = secim;
    }
    
    
   
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==secim.getAdmin()){
             new SuperAdminGirisGUI();
             secim.dispose();
        }
        if(e.getSource()==secim.getKullanici()){
            new KullaniciGirisGUI();
            secim.dispose();
        }
    }
}
