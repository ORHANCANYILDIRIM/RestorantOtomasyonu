package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.KullaniciController;
import RestoranOtomasyon.Gui.MüsteriGUI;
import RestoranOtomasyon.Gui.SuperAdminGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class MüsteriAction implements ActionListener{

    private MüsteriGUI müsteri;
    private KullaniciController kc;

    public MüsteriAction(MüsteriGUI müsteri) {
        this.müsteri = müsteri;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == müsteri.getEkle()) {
            String adsoyad = müsteri.getAdSoyadF().getText();
            String kullaniciAdi = müsteri.getKullaniciAdiF().getText();
            String sifre = müsteri.getSifreF().getText();
            if (adsoyad.length() == 0 || sifre.length() == 0 || kullaniciAdi.length() == 0) {
                JOptionPane.showMessageDialog(null, "Eksik alanlari doldurunuz!");
            } else {
                try {
                    getKc().create(adsoyad, kullaniciAdi, sifre);
                    müsteri.getAdSoyadF().setText(null);
                    müsteri.getKullaniciAdiF().setText(null);
                    müsteri.getSifreF().setText(null);
                    müsteri.MüsteriModelGuncelle();
                } catch (IOException ex) {
                    Logger.getLogger(PersonelAction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        if (e.getSource() == müsteri.getGeriDon()) {
            new SuperAdminGUI();
            müsteri.dispose();
        }
    }

    public KullaniciController getKc() {
        if(kc==null){
           kc=new KullaniciController();
        }
        return kc;
    }

    public void setKc(KullaniciController kc) {
        this.kc = kc;
    }
    
    
}
