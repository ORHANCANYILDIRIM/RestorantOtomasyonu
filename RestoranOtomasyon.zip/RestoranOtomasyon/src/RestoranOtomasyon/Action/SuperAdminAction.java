
package RestoranOtomasyon.Action;

import RestoranOtomasyon.Gui.MasaGUI;
import RestoranOtomasyon.Gui.MutfakGUI;
import RestoranOtomasyon.Gui.MüsteriGUI;
import RestoranOtomasyon.Gui.PersonelGUI;
import RestoranOtomasyon.Gui.SecimGUI;
import RestoranOtomasyon.Gui.SuperAdminGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class SuperAdminAction implements ActionListener{
    private SuperAdminGUI superAdmin;

    public SuperAdminAction(SuperAdminGUI superAdmin) {
        this.superAdmin = superAdmin;
    } 
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==superAdmin.getCikis()){
            JOptionPane.showMessageDialog(null,"Oturum Kapatılıyor");
            new SecimGUI();
            superAdmin.dispose();
        }
        if(e.getSource()==superAdmin.getMasa()){
            try {
                new MasaGUI();
            } catch (IOException ex) {
                Logger.getLogger(SuperAdminAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            superAdmin.dispose();
        }
        if(e.getSource()==superAdmin.getMüsteriler()){
            try {
                new MüsteriGUI();
            } catch (IOException ex) {
                Logger.getLogger(SuperAdminAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            superAdmin.dispose();
        }
        if(e.getSource()==superAdmin.getMutfak()){
            try {
                new MutfakGUI();
            } catch (IOException ex) {
                Logger.getLogger(SuperAdminAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            superAdmin.dispose();
        }
        if(e.getSource()==superAdmin.getPersonel()){
            try {
                new PersonelGUI();
            } catch (IOException ex) {
                Logger.getLogger(SuperAdminAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            superAdmin.dispose();
        }
    }
    
}
