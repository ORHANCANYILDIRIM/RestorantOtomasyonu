
package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.KullaniciController;
import RestoranOtomasyon.Gui.KayıtOlGUI;
import RestoranOtomasyon.Gui.KullaniciGUI;
import RestoranOtomasyon.Gui.KullaniciGirisGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class KullaniciGirisAction implements ActionListener{
    private KullaniciGirisGUI giris;

    public KullaniciGirisAction(KullaniciGirisGUI giris) {
        this.giris = giris;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == giris.getGiris()){
           String KullanıcıAdı=giris.getKullaniciAdiF().getText();
           String Parola=giris.getParolaF().getText();
           KullaniciController k=new KullaniciController();
           try {
               if(k.checkUser(KullanıcıAdı, Parola) == true){
                  JOptionPane.showMessageDialog(null, "Giris basariyla yapilmistir");
                  new KullaniciGUI();
                  giris.dispose();
               }
               else{
                   JOptionPane.showMessageDialog(null, "Girdiginiz bilgiler hatalidir!");
               }
           } catch (IOException ex) {
               Logger.getLogger(KullaniciGirisAction.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
       if(e.getSource()== giris.getKayitOl()){
           KayıtOlGUI k =new KayıtOlGUI();           
           giris.dispose();
  
       }
    }
}
