package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.PersonelController;
import RestoranOtomasyon.Gui.PersonelGUI;
import RestoranOtomasyon.Gui.SuperAdminGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class PersonelAction implements ActionListener{
    private PersonelGUI personel;
    private PersonelController pc;

    public PersonelAction(PersonelGUI personel) {
        this.personel = personel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==personel.getEkle()){
            String adsoyad=personel.getAdSoyadF().getText();
            String gorev=personel.getGorevF().getText();
            String maas=personel.getMaasF().getText();
            if(adsoyad.length()==0 || maas.length()==0 || gorev.length()==0){
                JOptionPane.showMessageDialog(null, "Eksik alanlari doldurunuz!");
            }
            else{
                try {
                    getPc().create(adsoyad, gorev, maas);
                    personel.getAdSoyadF().setText(null);
                    personel.getGorevF().setText(null);
                    personel.getMaasF().setText(null);
                    personel.PersonelModelGuncelle();
                } catch (IOException ex) {
                    Logger.getLogger(PersonelAction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        if(e.getSource()==personel.getSil()){
             String Id=personel.getIDF().getText();
            try {
                getPc().sil(Id);
                personel.PersonelModelGuncelle();
            } catch (IOException ex) {
                Logger.getLogger(PersonelAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(e.getSource()==personel.getGeriDon()){
            new SuperAdminGUI();
            personel.dispose();
        }
    }

    public PersonelController getPc() {
        if(pc==null){
           pc=new PersonelController();
        }
        return pc;
    }

}
