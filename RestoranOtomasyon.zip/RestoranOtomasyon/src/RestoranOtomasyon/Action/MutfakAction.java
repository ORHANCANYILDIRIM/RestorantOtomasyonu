package RestoranOtomasyon.Action;

public class MutfakAction {
    
}
