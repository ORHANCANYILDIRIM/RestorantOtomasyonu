package RestoranOtomasyon.Action;

import RestoranOtomasyon.Controller.MutfakController;
import RestoranOtomasyon.Gui.MutfakGUI;
import RestoranOtomasyon.Gui.SuperAdminGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class MutfakAction implements ActionListener{
    private MutfakGUI mutfak;
    private MutfakController Mc;
    
    public MutfakAction(MutfakGUI mutfak) {
        this.mutfak=mutfak;
    }   
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==mutfak.getSiparisEt()){
            String yemekadi=mutfak.getYemekAdiF().getText();
            String fiyat=mutfak.getFiyatF().getText();
            int fiyat2=Integer.parseInt(fiyat);
            if(yemekadi.length()==0 || fiyat.length()==0){
                JOptionPane.showMessageDialog(null, "Eksik alanlari doldurunuz!");
            }
            else{
                try {
                    getMc().create(yemekadi, fiyat2);
                    mutfak.getYemekAdiF().setText(null);
                    mutfak.getFiyatF().setText(null);
                    mutfak.MutfakModelGuncelle();
                } catch (IOException ex) {
                    Logger.getLogger(PersonelAction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }
        if(e.getSource()==mutfak.getGeriDon()){
            new SuperAdminGUI();
            mutfak.dispose();
        }
        if(e.getSource()==mutfak.getSil()){
            String Id=mutfak.getIDF().getText();
            try {
                getMc().sil(Id);
                 mutfak.MutfakModelGuncelle();
            } catch (IOException ex) {
                Logger.getLogger(MutfakAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public MutfakController getMc() {
        if(Mc==null){
            Mc=new MutfakController();
        }
        return Mc;
    }

   
    
}
