package RestoranOtomasyon.DosyaIslemleri;
//ekle kontrol sil güncelle 

import RestoranOtomasyon.Entitiy.BaseEntitiy;
import RestoranOtomasyon.Entitiy.Mutfak;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DosyaIslemleri {

    public void Ekle(BaseEntitiy be, String Txt) {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\zafer\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\" + Txt, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.append(be.toString() + "\n");
            }
        } catch (IOException e) {
        }
    }

    public void Sil( String Id,String Txt) throws IOException {
        System.out.println("dosya");
        try {
            List<String> yeniDosya;
            try ( FileReader fR = new FileReader("C:\\Users\\Orhan\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\" + Txt)) {
                try ( BufferedReader bR = new BufferedReader(fR)) {
                    String line = bR.readLine();
                    yeniDosya = new ArrayList<>();
                    while (line != null) {
                        System.out.println("dongu");
                        String[] parts = line.split(";");
                        if (parts[0].equals(Id)) {
                            System.out.println("if");
                            line = bR.readLine();
                        } else {
                            yeniDosya.add(line);
                            line = bR.readLine();
                        }
                    }
                    bR.close();
                }
                fR.close();
            }
            try ( BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\Orhan\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\" + Txt))) {
                for (String satir : yeniDosya) {
                    writer.write(satir + "\n");
                }
                writer.close();
            }
        } catch (IOException e) {
        }
    }

}
