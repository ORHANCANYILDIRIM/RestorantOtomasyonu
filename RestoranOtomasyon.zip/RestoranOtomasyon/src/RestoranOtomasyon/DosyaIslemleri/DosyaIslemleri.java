package RestoranOtomasyon.DosyaIslemleri;
//ekle kontrol sil güncelle 

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

public class DosyaIslemleri {

    public void KullaniciEkle(String veri, String Txt) {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\zafer\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\" + Txt, true);
            try (BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.append(veri+"\n");
            }
        } catch (IOException e) {
        }
    }

//    public boolean checkUser(String username, String password, String Txt) throws IOException {
//        boolean Kontrol = false;
//        try {
//            FileReader fileReader = new FileReader("C:\\Users\\zafer\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\" + Txt);
//            try (BufferedReader bufferedReader = new BufferedReader(fileReader)) {
//                String line = bufferedReader.readLine();
//                while (line != null) {
//                    String[] parts = line.split(";");
//                    if (parts[1].equals(username) && parts[2].equals(password)) {
//                        JOptionPane.showMessageDialog(null, "Giris basariyla yapildi.");
//                        Kontrol = true;
//                        break;
//                    }
//                    line = bufferedReader.readLine();
//                }
//
//                if (line == null) {
//                    JOptionPane.showMessageDialog(null, "Girdiginiz bilgiler hatalidir.");
//                    return false;
//                }
//            }
//        } catch (IOException e) {
//        }
//        return Kontrol;
//    }

}
