package RestoranOtomasyon.Entitiy;

import Yardımcı.IdSayac;
import java.io.IOException;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mutfak implements BaseEntitiy{
    private int ID;
    private String YemekAdi;
    private int Fiyat;
    

    public Mutfak() {
    }

    public Mutfak(int ID, String YemekAdi, int Fiyat) {
        this.ID = ID;
        this.YemekAdi = YemekAdi;
        this.Fiyat = Fiyat;
       
    }     

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.ID;
        hash = 97 * hash + Objects.hashCode(this.YemekAdi);
        hash = (int) (97 * hash + this.Fiyat);
       
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Mutfak other = (Mutfak) obj;
        return true;
    }
    
    @Override
    public String toString() {
        try {
            return (IdSayac.idSayacMutfak()+1)+";"+YemekAdi+";"+Fiyat;
          
        } catch (IOException ex) {
            Logger.getLogger(Mutfak.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getYemekAdi() {
        return YemekAdi;
    }

    public void setYemekAdi(String YemekAdi) {
        this.YemekAdi = YemekAdi;
    }

    public int getFiyat() {
        return Fiyat;
    }

    public void setFiyat(int Fiyat) {
        this.Fiyat = Fiyat;
    }
    
    
}
