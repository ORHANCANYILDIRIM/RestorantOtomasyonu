package RestoranOtomasyon.Entitiy;

public class KullaniciSiparisBilgi implements BaseEntitiy {

    private int hesap;
    private String KartNumarası;
    private String KartAdSoyad;
    private String KartSKT;
    private String KartCVV;
    private Kullanici kullanici;

    public KullaniciSiparisBilgi() {
    }
    
    public KullaniciSiparisBilgi(int hesap, String KartNumarası, String KartAdSoyad, String KartSKT, String KartCVV, Kullanici kullanici) {
        this.hesap = hesap;
        this.KartNumarası = KartNumarası;
        this.KartAdSoyad = KartAdSoyad;
        this.KartSKT = KartSKT;
        this.KartCVV = KartCVV;
        this.kullanici = kullanici;
    }

    
    
    @Override
    public String toString() {
        return kullanici+";"+KartAdSoyad+";"+KartNumarası+";"+KartCVV+";"+KartSKT;
    }

    public int getHesap() {
        return hesap;
    }

    public void setHesap(int hesap) {
        this.hesap = hesap;
    }

    public String getKartNumarası() {
        return KartNumarası;
    }

    public void setKartNumarası(String KartNumarası) {
        this.KartNumarası = KartNumarası;
    }

    public String getKartAdSoyad() {
        return KartAdSoyad;
    }

    public void setKartAdSoyad(String KartAdSoyad) {
        this.KartAdSoyad = KartAdSoyad;
    }

    public String getKartSKT() {
        return KartSKT;
    }

    public void setKartSKT(String KartSKT) {
        this.KartSKT = KartSKT;
    }

    public String getKartCVV() {
        return KartCVV;
    }

    public void setKartCVV(String KartCVV) {
        this.KartCVV = KartCVV;
    }

    public Kullanici getKullanici() {
        return kullanici;
    }

    public void setKullanici(Kullanici kullanici) {
        this.kullanici = kullanici;
    }

}
