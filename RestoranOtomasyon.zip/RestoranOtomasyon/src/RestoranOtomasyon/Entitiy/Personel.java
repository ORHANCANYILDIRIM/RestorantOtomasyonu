
package RestoranOtomasyon.Entitiy;

import Yardımcı.IdSayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Personel extends Insan implements BaseEntitiy{
    private String Gorev;
    private String Maas;
    
    public Personel() {
    }
    
    public Personel(int ID) {
        super(ID);
    }

    public Personel(String Gorev, String Maas, String IsimSoyisım) {
        super(IsimSoyisım);
        this.Gorev = Gorev;
        this.Maas = Maas;
    }
    
    

    public Personel(int ID,String IsimSoyisım,String Gorev, String Maas,String Type) {
        super(ID, IsimSoyisım, Type);
        this.Gorev = Gorev;
        this.Maas = Maas;
    }
    
    
    
    @Override
    public int hashCode() {
        return super.hashCode();
    }
     
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); 
    }
    
    @Override
    public String toString() {
        try {
            return (IdSayac.idSayac()+1)+";"+getIsimSoyisım()+";"+getGorev()+";"+getMaas()+";"+"Personel";
        } catch (IOException ex) {
            Logger.getLogger(Personel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public String getGorev() {
        return Gorev;
    }

    public void setGorev(String Gorev) {
        this.Gorev = Gorev;
    }

    public String getMaas() {
        return Maas;
    }

    public void setMaas(String Maas) {
        this.Maas = Maas;
    }
    
    
}
