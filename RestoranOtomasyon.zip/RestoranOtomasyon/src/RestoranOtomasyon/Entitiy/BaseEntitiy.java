package RestoranOtomasyon.Entitiy;

public interface BaseEntitiy {
    
}
