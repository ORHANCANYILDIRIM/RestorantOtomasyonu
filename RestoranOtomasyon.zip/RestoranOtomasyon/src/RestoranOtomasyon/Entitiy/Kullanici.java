package RestoranOtomasyon.Entitiy;

import Yardımcı.IdSayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;



public class Kullanici extends Insan{

    public Kullanici() {
    }

    public Kullanici(int ID) {
        super(ID);
    }
  
    public Kullanici(String KullaniciAdi, String Parola) {
        super(KullaniciAdi, Parola);
    }
    
    
    public Kullanici(int ID, String IsimSoyisım, String KullaniciAdi, String Parola, String Type) {
        super(ID, IsimSoyisım, KullaniciAdi, Parola, Type);
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); 
    }

    @Override
    public int hashCode() {
        return super.hashCode(); 
    }


    @Override
    public String toString() {
        try {
            return (IdSayac.idSayac()+1)+";"+getIsimSoyisım()+";"+getKullaniciAdi()+";"+getParola()+";"+"Kullanici";
        } catch (IOException ex) {
            Logger.getLogger(Kullanici.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    
    
   

    
    
    
  

    
    
    
    
    
}
