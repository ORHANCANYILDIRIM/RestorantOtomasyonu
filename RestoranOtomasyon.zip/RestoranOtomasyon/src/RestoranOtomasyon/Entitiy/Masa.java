package RestoranOtomasyon.Entitiy;

import Yardımcı.IdSayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Masa implements BaseEntitiy{   
    private String Doluluk;
    private int ID;
    
    
    public Masa() {
    }
    
    public Masa(String Doluluk) {  
        this.Doluluk = Doluluk;
    }

    public Masa(int ID,String Doluluk) {
        this.Doluluk = Doluluk;
        this.ID = ID;
    }
    
    

    public String getDoluluk() {
        return Doluluk;
    }

    public void setDoluluk(String Doluluk) {
        this.Doluluk = Doluluk;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    

    @Override
    public String toString() {
        try {
            return  (IdSayac.idSayacMasa()+1)+";"+Doluluk;
        } catch (IOException ex) {
            Logger.getLogger(Masa.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
}
