package RestoranOtomasyon.Entitiy;

import java.util.Objects;

public class SuperAdmin {
    private String IsimSoyisim;
    private String KullaniciAdi;
    private String Parola;

    public SuperAdmin() {
    }

    public SuperAdmin(String KullaniciAdi, String Parola) {
        this.KullaniciAdi = KullaniciAdi;
        this.Parola = Parola;
    }

    public SuperAdmin(String IsimSoyisim, String KullaniciAdi, String Parola) {
        this.IsimSoyisim = IsimSoyisim;
        this.KullaniciAdi = KullaniciAdi;
        this.Parola = Parola;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 31 * hash + Objects.hashCode(this.KullaniciAdi);
        hash = 31 * hash + Objects.hashCode(this.Parola);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SuperAdmin other = (SuperAdmin) obj;
        if (!Objects.equals(this.KullaniciAdi, other.KullaniciAdi)) {
            return false;
        }
        return Objects.equals(this.Parola, other.Parola);
    }  

    public String getIsimSoyisim() {
        return IsimSoyisim;
    }

    public void setIsimSoyisim(String IsimSoyisim) {
        this.IsimSoyisim = IsimSoyisim;
    }

    public String getKullaniciAdi() {
        return KullaniciAdi;
    }

    public void setKullaniciAdi(String KullaniciAdi) {
        this.KullaniciAdi = KullaniciAdi;
    }

    public String getParola() {
        return Parola;
    }

    public void setParola(String Parola) {
        this.Parola = Parola;
    }

    @Override
    public String toString() {
        return IsimSoyisim+";"+KullaniciAdi+";"+Parola;
    }
    
  
    
}
