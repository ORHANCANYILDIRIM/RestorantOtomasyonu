package RestoranOtomasyon.Entitiy;

import java.util.Objects;


public abstract class Insan {
    private int ID;
    private String IsimSoyisım;
    private String KullaniciAdi;
    private String Parola;
    private String Type;
    
    public Insan() {
    }
    
    public Insan(int ID) {
        this.ID = ID;
    }

    public Insan(String IsimSoyisım) {
        this.IsimSoyisım = IsimSoyisım;
    }
    
    
    public Insan(String KullaniciAdi, String Parola) {
        this.KullaniciAdi = KullaniciAdi;
        this.Parola = Parola;
    }

    public Insan(int ID, String IsimSoyisım, String KullaniciAdi, String Type) {
        this.ID = ID;
        this.IsimSoyisım = IsimSoyisım;
        this.KullaniciAdi = KullaniciAdi;
        this.Type = Type;
    }

    public Insan(int ID, String IsimSoyisım, String Type) {
        this.ID = ID;
        this.IsimSoyisım = IsimSoyisım;
        this.Type = Type;
    }
    
    

    public Insan(int ID, String IsimSoyisım, String KullaniciAdi, String Parola, String Type) {
        this.ID = ID;
        this.IsimSoyisım = IsimSoyisım;
        this.KullaniciAdi = KullaniciAdi;
        this.Parola = Parola;
        this.Type = Type;
    }



    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getIsimSoyisım() {
        return IsimSoyisım;
    }

    public void setIsimSoyisım(String IsimSoyisım) {
        this.IsimSoyisım = IsimSoyisım;
    }

    public String getKullaniciAdi() {
        return KullaniciAdi;
    }

    public void setKullaniciAdi(String KullaniciAdi) {
        this.KullaniciAdi = KullaniciAdi;
    }

    public String getParola() {
        return Parola;
    }

    public void setParola(String Parola) {
        this.Parola = Parola;
    }  

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.KullaniciAdi);
        hash = 97 * hash + Objects.hashCode(this.Parola);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Insan other = (Insan) obj;
        if (!Objects.equals(this.KullaniciAdi, other.KullaniciAdi)) {
            return false;
        }
        return Objects.equals(this.Parola, other.Parola);
    }

    @Override
    public String toString() {
        return "Insan{" + "ID=" + ID + ", IsimSoyis\u0131m=" + IsimSoyisım + ", KullaniciAdi=" + KullaniciAdi + ", Parola=" + Parola + ", Type=" + Type + '}';
    }

}
