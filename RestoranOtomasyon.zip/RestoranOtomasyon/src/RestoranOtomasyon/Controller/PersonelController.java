
package RestoranOtomasyon.Controller;

import RestoranOtomasyon.DAO.PersonelDAO;
import RestoranOtomasyon.Entitiy.Kullanici;
import RestoranOtomasyon.Entitiy.Personel;
import java.io.IOException;
import java.util.List;

public class PersonelController {
    private Personel personel;
    private List<Kullanici> list;
    private PersonelDAO dao; 

    public PersonelController() {
    }
    
    public void create(String IsimSoyisim, String gorev, String maas) throws IOException{
        Personel newpersonel = this.getPersonel();
        newpersonel.setIsimSoyisım(IsimSoyisim);
        newpersonel.setGorev(gorev);
        newpersonel.setMaas(maas);
        this.getDao().insert(newpersonel);   
    }

    public Personel getPersonel() {
        if(this.personel==null){
            personel=new Personel();
        }
        return personel;
    }

    public void setPersonel(Personel personel) {
        this.personel = personel;
    }

    public List<Kullanici> getList() {
        return list;
    }

    public void setList(List<Kullanici> list) {
        this.list = list;
    }

    public PersonelDAO getDao() {
        if(this.dao==null){
            dao=new PersonelDAO();
        }
        return dao;
    }

    public void setDao(PersonelDAO dao) {
        this.dao = dao;
    }
    
    
}
