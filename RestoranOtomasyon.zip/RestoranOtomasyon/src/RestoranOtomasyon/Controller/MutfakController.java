package RestoranOtomasyon.Controller;

import RestoranOtomasyon.DAO.MutfakDAO;
import RestoranOtomasyon.Entitiy.Kullanici;
import RestoranOtomasyon.Entitiy.Mutfak;
import java.io.IOException;
import java.util.List;

public class MutfakController {
    private Mutfak mutfak;
    private List<Mutfak> list;
    private MutfakDAO dao; 

    public MutfakController() {
    }
    
    public void create(String YemekAdi, int Fiyat) throws IOException{
        Mutfak newmutfak = this.getMutfak();
        newmutfak.setYemekAdi(YemekAdi);
        newmutfak.setFiyat(Fiyat);
       
        this.getDao().insert(newmutfak);   
    }
    
     public void sil(String Id) throws IOException{
        System.out.println("controller");
        this.getDao().sil(Id);   
    }
     
        public boolean checkyemek(String yemekadi) throws IOException {
        return getDao().checkyemek(yemekadi);
        }
     

    public Mutfak getMutfak() {
        if(mutfak==null){
            mutfak=new Mutfak();
        }
        return mutfak;
    }

    public void setMutfak(Mutfak mutfak) {
        this.mutfak = mutfak;
    }

    public List<Mutfak> getList() {
        return list;
    }

    public void setList(List<Mutfak> list) {
        this.list = list;
    }

    public MutfakDAO getDao() {
        if(dao==null){
            dao=new MutfakDAO();
        }
        return dao;
    }

    public void setDao(MutfakDAO dao) {
        this.dao = dao;
    }
    
    
}
