package RestoranOtomasyon.Controller;

public class MutfakController {
    
}
