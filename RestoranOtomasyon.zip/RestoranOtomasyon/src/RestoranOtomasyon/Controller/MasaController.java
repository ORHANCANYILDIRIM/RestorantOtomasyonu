package RestoranOtomasyon.Controller;

import RestoranOtomasyon.DAO.MasaDAO;
import RestoranOtomasyon.Entitiy.Masa;

import java.io.IOException;
import java.util.List;

public class MasaController {
    private Masa masa;
    private List<Masa> list;
    private MasaDAO dao; 

    public MasaController() {
    }
    
    public void create(String Doluluk) throws IOException{
        Masa newMasa = this.getMasa();
        newMasa.setDoluluk(Doluluk );
        this.getDao().insert(newMasa);   
    }

     public void sil(String Id) throws IOException{
        System.out.println("controller");
        this.getDao().sil(Id);   
    }
    
    public Masa getMasa() {
        if(masa==null){
            masa=new Masa();
        }
        return masa;
    }

    public void setMasa(Masa masa) {
        this.masa = masa;
    }

    public List<Masa> getList() {
        return list;
    }

    public void setList(List<Masa> list) {
        this.list = list;
    }

    public MasaDAO getDao() {
        if(dao==null){
            dao=new MasaDAO();
        }
        return dao;
    }

    public void setDao(MasaDAO dao) {
        this.dao = dao;
    }
    
    
    
}
