
package RestoranOtomasyon.Controller;

import RestoranOtomasyon.DAO.SuperAdminDAO;
import RestoranOtomasyon.Entitiy.SuperAdmin;
import java.io.IOException;
import java.util.List;


public class SuperAdminController {
    private SuperAdmin SAdmin;
    private List<SuperAdmin> list;
    private SuperAdminDAO dao;
  
    public SuperAdminController() {
    }
    
    public void create(String IsimSoyisim,String KullaniciAdi,String Parola) throws IOException{
        SuperAdmin newSAdmin = this.getSuperAdmin();
        newSAdmin.setIsimSoyisim(IsimSoyisim);
        newSAdmin.setKullaniciAdi(KullaniciAdi);
        newSAdmin.setParola(Parola);
        this.getDao().insert(newSAdmin);        
    }

    public boolean checkUser(String username, String password) throws IOException {
        SuperAdmin newkullanici = this.getSuperAdmin();
        newkullanici.setKullaniciAdi(username);
        newkullanici.setParola(password);
        return getDao().checkuser(newkullanici);
    }

    public SuperAdmin getSuperAdmin() {
        if(this.SAdmin==null){
            SAdmin=new SuperAdmin();
        }
        return SAdmin;
    }

    public void setSuperAdmin(SuperAdmin kullanıcı) {
        this.SAdmin = SAdmin;
    }

    public List<SuperAdmin> getList() {
        return list;
    }

    public void setList(List<SuperAdmin> list) {
        this.list = list;
    }

    public SuperAdminDAO getDao() {
        if(this.dao==null){
            dao=new SuperAdminDAO();
        }
        return dao;
    }

    public void setDao(SuperAdminDAO dao) {
        this.dao = dao;
    }
    
}
