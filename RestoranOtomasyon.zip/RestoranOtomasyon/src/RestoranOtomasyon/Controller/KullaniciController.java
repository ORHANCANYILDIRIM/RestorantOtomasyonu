package RestoranOtomasyon.Controller;

import RestoranOtomasyon.DAO.KullaniciDAO;
import RestoranOtomasyon.Entitiy.Kullanici;
import java.io.IOException;
import java.util.List;


public class KullaniciController {
    private Kullanici kullanici;
    private List<Kullanici> list;
    private KullaniciDAO dao; 

    public KullaniciController() {
    }
    
    public void create(String IsimSoyisim,String KullaniciAdi,String Parola) throws IOException{
        Kullanici newkullanıcı = this.getKullanıcı();
        newkullanıcı.setIsimSoyisım(IsimSoyisim);
        newkullanıcı.setKullaniciAdi(KullaniciAdi);
        newkullanıcı.setParola(Parola);
        this.getDao().insert(newkullanıcı);   
    }
    

    public boolean checkUser(String username, String password) throws IOException {
        Kullanici newkullanici = this.getKullanıcı();
        newkullanici.setKullaniciAdi(username);
        newkullanici.setParola(password);   
        return getDao().checkuser(newkullanici);
    }

    public Kullanici getKullanıcı() {
        if(this.kullanici==null){
            kullanici=new Kullanici();
        }
        return kullanici;
    }

    public void setKullanıcı(Kullanici kullanıcı) {
        this.kullanici = kullanıcı;
    }

    public List<Kullanici> getList() {
        return list;
    }

    public void setList(List<Kullanici> list) {
        this.list = list;
    }

    public KullaniciDAO getDao() {
        if(this.dao==null){
            dao=new KullaniciDAO();
        }
        return dao;
    }

    public void setDao(KullaniciDAO dao) {
        this.dao = dao;
    }
    
}
