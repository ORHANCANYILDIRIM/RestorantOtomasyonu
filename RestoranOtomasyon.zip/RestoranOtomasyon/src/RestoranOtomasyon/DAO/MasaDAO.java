package RestoranOtomasyon.DAO;

import RestoranOtomasyon.DosyaIslemleri.DosyaIslemleri;
import RestoranOtomasyon.Entitiy.Masa;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MasaDAO {
    DosyaIslemleri dosya = new DosyaIslemleri();
    private List<Masa> masalist = new ArrayList<>();

    public void insert(Masa m) {
        dosya.Ekle(m, "masa.txt");
    }
    
    public void sil(String ID) throws IOException {
        System.out.println("dao");
        dosya.Sil(ID, "Masa.txt");
    }

    public List<Masa> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Orhan\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Masa.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(";");
                Masa M=new Masa(Integer.parseInt(parts[0]),parts[1]);
                masalist.add(M);
            
            line = bR.readLine();       
        }
        return this.masalist;
    }
}
