
package RestoranOtomasyon.DAO;

import RestoranOtomasyon.DosyaIslemleri.DosyaIslemleri;
import RestoranOtomasyon.Entitiy.SuperAdmin;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class SuperAdminDAO {
    DosyaIslemleri dosya = new DosyaIslemleri();
    private List<SuperAdmin> SuperAdminlist = new ArrayList<>();

    public void insert(SuperAdmin SA) {
        DosyaIslemleri ds = new DosyaIslemleri();
        ds.KullaniciEkle(SA.toString(), "Kullanici.txt");
    }

    public List<SuperAdmin> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\zafer\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Kullanici.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        
        while (line != null) {
            String[] parts = line.split(";");          
            if("Admin".equals(parts[4])){
                SuperAdmin K=new SuperAdmin(parts[2],parts[3]);
                SuperAdminlist.add(K);
            }
            
            line = bR.readLine();       
        }
        return this.SuperAdminlist;
    }

    public boolean checkuser(SuperAdmin YeniSuperAdmin) throws IOException {
        List<SuperAdmin> list = this.getList();
        boolean check = false;       
        for (SuperAdmin k : list) {
            if (k.equals(YeniSuperAdmin)) {
                JOptionPane.showMessageDialog(null, "Giris basariyla yapildi.");
                check = true;
            }
        }
        return check;
    }

}
