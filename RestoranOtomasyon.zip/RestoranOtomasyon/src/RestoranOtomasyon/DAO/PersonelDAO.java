package RestoranOtomasyon.DAO;

import RestoranOtomasyon.DosyaIslemleri.DosyaIslemleri;
import RestoranOtomasyon.Entitiy.Personel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PersonelDAO {

    DosyaIslemleri dosya = new DosyaIslemleri();
    private List<Personel> personellist = new ArrayList<>();

    public void insert(Personel p) {
        dosya.Ekle(p, "Kullanici.txt");
    }

    public void sil(String ID) throws IOException {
        System.out.println("dao");
        dosya.Sil(ID, "Kullanici.txt");
    }

    public List<Personel> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Orhan\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Kullanici.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(";");
            if ("Personel".equals(parts[4])) {
                Personel P = new Personel(Integer.parseInt(parts[0]), parts[1], parts[2], parts[3], parts[4]);
                personellist.add(P);
            }
            line = bR.readLine();
        }
        return this.personellist;
    }

}
