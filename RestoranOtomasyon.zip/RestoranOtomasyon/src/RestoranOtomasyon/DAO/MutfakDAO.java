package RestoranOtomasyon.DAO;

import RestoranOtomasyon.DosyaIslemleri.DosyaIslemleri;
import RestoranOtomasyon.Entitiy.Kullanici;
import RestoranOtomasyon.Entitiy.Mutfak;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MutfakDAO {

    DosyaIslemleri dosya = new DosyaIslemleri();
    private List<Mutfak> mutfaklist = new ArrayList<>();

    public void insert(Mutfak m) throws IOException {
        dosya.Ekle(m, "Menu.txt");
    }

    public void sil(String ID) throws IOException {     
        System.out.println("dao");
        dosya.Sil(ID, "Menu.txt");
    }

    
     public boolean checkyemek(String yemekadi) throws IOException {
        List<Mutfak> list = this.getList();
        boolean check = false;       
        for (Mutfak k : list) {
            if (k.getYemekAdi().equals(yemekadi)) {
                check = true;
            }
        }
        return check;
    }
    
    public List<Mutfak> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Orhan\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Menu.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(";");
            Mutfak M = new Mutfak(Integer.parseInt(parts[0]), parts[1], Integer.parseInt(parts[2]));
            mutfaklist.add(M);
            line = bR.readLine();
        }
        return this.mutfaklist;
    }
}
