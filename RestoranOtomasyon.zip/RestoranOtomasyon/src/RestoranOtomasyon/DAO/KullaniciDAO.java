package RestoranOtomasyon.DAO;

import RestoranOtomasyon.DosyaIslemleri.DosyaIslemleri;
import RestoranOtomasyon.Entitiy.Kullanici;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class KullaniciDAO {

    DosyaIslemleri dosya = new DosyaIslemleri();
    private List<Kullanici> kullanicilist = new ArrayList<>();

    public void insert(Kullanici k) {
        dosya.Ekle(k, "Kullanici.txt");
    }
    
    public void sil(String ID) throws IOException {
        dosya.Sil(ID, "Kullanici.txt");
    }
    
    public List<Kullanici> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Orhan\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Kullanici.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(";");
            if("Kullanici".equals(parts[4])){
                Kullanici K=new Kullanici(parts[2],parts[3]);
                kullanicilist.add(K);
            }
            line = bR.readLine();       
        }
        return this.kullanicilist;
    }

    public List<Kullanici> getList2() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Orhan\\Documents\\NetBeansProjects\\RestoranOtomasyon\\src\\RestoranOtomasyon\\DosyaIslemleri\\Kullanici.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(";");
            if("Kullanici".equals(parts[4])){
                Kullanici P=new Kullanici(Integer.parseInt(parts[0]),parts[1],parts[2],parts[3],parts[4]);
                kullanicilist.add(P);
            }
            line = bR.readLine();       
        }
        return this.kullanicilist;
    }
    
    
    public boolean checkuser(Kullanici YeniKullanici) throws IOException {
        List<Kullanici> list = this.getList();
        boolean check = false;       
        for (Kullanici k : list) {
            if (k.equals(YeniKullanici)) {
                check = true;
            }
        }
        return check;
    }

}
