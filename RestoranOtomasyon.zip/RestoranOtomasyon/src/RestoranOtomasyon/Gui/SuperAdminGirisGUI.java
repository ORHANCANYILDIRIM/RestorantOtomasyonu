package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.SuperAdminGirisAction;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SuperAdminGirisGUI extends JFrame {

    private JLabel AdminAdi;
    private JTextField AdminAdiF;
    private JLabel AdminSifre;
    private JPasswordField AdminSifreF;
    private JButton AGiris;
    private JButton ACıkıs;

    public SuperAdminGirisGUI() {
        initJFrame();

    }

    private void initJFrame() {
        add(initPanel());
        setTitle("Admin Girisi");
        setLocationRelativeTo(null);
        setBounds(750, 300, 400, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        JPanel AdminPanel = new JPanel();
        AdminPanel.setBackground(new Color(255,240,255));
        AdminPanel.setLayout(null);

        AdminPanel.add(getAdminAdi());
        AdminPanel.add(getAdminAdiF());
        AdminPanel.add(getAdminSifre());
        AdminPanel.add(getAdminSifreF());
        AdminPanel.add(getAGiris());
        AdminPanel.add(getACıkıs());
        
        return AdminPanel;
    }

    public JLabel getAdminAdi() {
        if (AdminAdi == null) {
            AdminAdi = new JLabel("Admin kullanici adi :");
            AdminAdi.setBounds(75, 60, 120, 60);
        }
        return AdminAdi;
    }

    public void setAdminAdi(JLabel KullaniciAdi) {
        this.AdminAdi = AdminAdi;
    }

    public JTextField getAdminAdiF() {
        if (AdminAdiF == null) {
            AdminAdiF = new JTextField();
            AdminAdiF.setBounds(200, 75, 150, 30);
        }
        return AdminAdiF;
    }

    public void setAdminAdiF(JTextField KullaniciAdiF) {
        this.AdminAdiF = KullaniciAdiF;
    }

    public JLabel getAdminSifre() {
        if (AdminSifre == null) {
            AdminSifre = new JLabel("Sifre :");
            AdminSifre.setBounds(75, 120, 100, 60);
        }
        return AdminSifre;
    }

    public void setAdminSifre(JLabel Parola) {
        this.AdminSifre = Parola;
    }

    public JTextField getAdminSifreF() {
        if (AdminSifreF == null) {
            AdminSifreF = new JPasswordField(10);
            AdminSifreF.setBounds(200, 135, 150, 30);
        }
        return AdminSifreF;
    }

    public void setAdminSifreF(JPasswordField ParolaF) {
        this.AdminSifreF = ParolaF;
    }

    public JButton getAGiris() {
        if (AGiris == null) {
            AGiris = new JButton("Giris");
            AGiris.setBounds(225, 300, 100, 30);
            AGiris.setBackground(new Color(143,194,197));
            AGiris.addActionListener(new SuperAdminGirisAction(this) );
        }
        return AGiris;
    }

    public void setAGiris(JButton Giris) {
        this.AGiris = Giris;
    }

    public JButton getACıkıs() {
        if (ACıkıs == null) {
            ACıkıs = new JButton("Cikis");
            ACıkıs.setBounds(75, 300, 100, 30);
            ACıkıs.setBackground(new Color(186,153,187));
            ACıkıs.addActionListener(new SuperAdminGirisAction(this) );
        }
        return ACıkıs;
    }

    public void getAGiris(JButton Cıkıs) {
        this.ACıkıs = Cıkıs;
    }

}
