
package RestoranOtomasyon.Gui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class KullaniciOdemeGUI extends JFrame{
    private JLabel KartNumarasi;
    private JTextField KartNumarasiF;
    private JLabel Kartsahibi;
    private JTextField KartsahibiF;
    private JLabel SKT;
    private JTextField SKTF;
    private JLabel CVV;
    private JTextField CVVF;
    private JButton Kaydet;
    private JButton Cıkıs;

   

    public KullaniciOdemeGUI() {
        initJFrame();
       
    }
    
    
    
    private void initJFrame(){
        add(initPanel());
        setTitle("Kullanici Ödeme");
        setBounds(500,500, 600,400);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel OdemePanel =new JPanel();
        OdemePanel.setLayout(null);
        
        OdemePanel.add(getKartNumarasi());
        OdemePanel.add(getKartNumarasiF());
        OdemePanel.add(getKartsahibi());
        OdemePanel.add(getKartsahibiF());
        OdemePanel.add(getSKT());
        OdemePanel.add(getSKTF());
        OdemePanel.add(getCVV());
        OdemePanel.add(getCVVF());
        OdemePanel.add(getKaydet());
        OdemePanel.add(getCıkıs());
         
        return OdemePanel;
    }
     
    
    
    public JLabel getKartNumarasi() {
        if(KartNumarasi==null){
            this.KartNumarasi=new JLabel("Kart Numarası");
            KartNumarasi.setBounds(50, 20, 100, 60);
        }
        return KartNumarasi;
    }

    public void setKartNumarasi(JLabel KartNumarasi) {
        this.KartNumarasi = KartNumarasi;
    }

    public JTextField getKartNumarasiF() {
        if(KartNumarasiF==null){
            this.KartNumarasiF=new JTextField();
            KartNumarasiF.setBounds(50, 100, 150, 25);
        }
        return KartNumarasiF;
    }

    public void setKartNumarasiF(JTextField KartNumarasiF) {
        this.KartNumarasiF = KartNumarasiF;
    }
    
    public JLabel getKartsahibi() {
        if(Kartsahibi==null){
            Kartsahibi = new JLabel("Kart Üzerindeki İsim-Soyisim:");
            Kartsahibi.setBounds(50, 150, 100, 60);
        }
        return Kartsahibi;
    }

    public void setKartsahibi(JLabel Kartsahibi) {
        this.Kartsahibi = Kartsahibi;
    }

    public JTextField getKartsahibiF() {
        if(KartsahibiF==null){
            KartsahibiF = new JTextField();
            KartsahibiF.setBounds(50, 230, 150, 25);
        }
        return KartsahibiF;
    }

    public void setKartsahibiF(JTextField KartsahibiF) {
        this.KartsahibiF = KartsahibiF;
    }
                                                                        
    public JLabel getSKT() {
        if(SKT==null){
            SKT = new JLabel("Son Kullanma Tarihi :");
            SKT.setBounds(50, 280, 100, 60);
        }
        return SKT;
    }

    public void setSKT(JLabel SKT) {
        this.SKT = SKT;
    }

    public JTextField getSKTF() {
        if(SKTF==null){
            SKTF = new JTextField(10);
            SKTF.setBounds(50, 360, 150, 25);
        }
        return SKTF;
    }

    public void setSKTF(JTextField SKTF) {
        this.SKTF = SKTF;
    }
    
     public JLabel getCVV() {
        if(CVV==null){
            CVV= new JLabel("CVV :");
            CVV.setBounds(50, 410, 100, 60);
        }
        return CVV;
    }

    public void setCVV(JLabel CVV) {
        this.CVV = CVV;
    }

    public JTextField getCVVF() {
        if(CVVF==null){
            CVVF = new JTextField(10);
            CVVF.setBounds(50, 480, 150, 25);
        }
        return CVVF;
    }

    public void setCVVF(JTextField CVVF) {
        this.CVVF = CVVF;
    }

    public JButton getKaydet() {
        if(Kaydet==null){
            Kaydet = new JButton("Kaydet");
            Kaydet.setBounds(225, 530, 100, 30);
        }
        return Kaydet;
    }

    public void setKaydet(JButton Kaydet) {
        this.Kaydet = Kaydet;
    }

    public JButton getCıkıs() {
        if(Cıkıs==null){            
            Cıkıs = new JButton("Cikis");
            Cıkıs.setBounds(75, 530, 100, 30);
        }
        return Cıkıs;
    }

    public void setCıkıs(JButton Cıkıs) {
        this.Cıkıs = Cıkıs;
    }  
    
}
