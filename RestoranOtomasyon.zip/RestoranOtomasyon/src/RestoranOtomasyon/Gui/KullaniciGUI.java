
package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.KullaniciAction;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class KullaniciGUI extends JFrame{
    private JButton Siparisver;
    private JButton OnlineSiparisver;
    private JButton Rezervasyon;
    private JButton Ödeme;
    private JButton Cikis;
   
    public KullaniciGUI() {
       initJFrame();    
    }

    private void initJFrame(){
        add(initPanel());
        setTitle("Kullanici Sayfasi");
        setLocationRelativeTo(null);
        setBounds(450, 250, 850, 550);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    
    private JPanel initPanel(){
        JPanel KullaniciPanel =new JPanel();
        KullaniciPanel.setLayout(null);
        
        KullaniciPanel.add(getSiparisver());
        KullaniciPanel.add(getRezervasyon());

        KullaniciPanel.add(getOnlineSiparisver());
        KullaniciPanel.add(getÖdeme());

        KullaniciPanel.add(getCikis());
        
        
        
        return KullaniciPanel;
    }
    
    public JButton getSiparisver() {
        if(Siparisver==null){
            Siparisver=new JButton("Siparisver");
            Siparisver.setBounds(175, 50, 200, 170);
            Siparisver.setBackground(Color.lightGray);
        }
        return Siparisver;
    }

    public void setSiparisver(JButton Siparisver) {
        this.Siparisver = Siparisver;
    }

    public JButton getOnlineSiparisver() {
        if(OnlineSiparisver==null){
            OnlineSiparisver=new JButton("Online Siparis Ver");
            OnlineSiparisver.setBounds(425, 50, 200, 170);
            OnlineSiparisver.setBackground(Color.lightGray);
        }
        return OnlineSiparisver;
    }

    public void setOnlineSiparisver(JButton OnlineSiparisver) {
        this.OnlineSiparisver = OnlineSiparisver;
    }

    public JButton getRezervasyon() {
        if(Rezervasyon==null){
            Rezervasyon=new JButton("Rezervasyon");
            Rezervasyon.setBounds(175, 250, 200, 170);
            Rezervasyon.setBackground(Color.lightGray);
        }
        return Rezervasyon;
    }

    public void setRezervasyon(JButton Rezervasyon) {
        this.Rezervasyon = Rezervasyon;
    }

  

    public JButton getÖdeme() {
        if(Ödeme==null){
           Ödeme=new JButton("Ödeme");
           Ödeme.setBounds(425, 250, 200, 170);       
           Ödeme.setBackground(Color.lightGray);
           Ödeme.addActionListener(new KullaniciAction(this));
        }
        return Ödeme;
    }

    public void setÖdeme(JButton Ödeme) {
        this.Ödeme = Ödeme;
    }

   
    public JButton getCikis() {
        if(Cikis==null){
            Cikis=new JButton("Cikis");
            Cikis.setBounds(625, 450, 100, 30);
            Cikis.setBackground(Color.gray);
        }            
        return Cikis;
    }

    public void setCikis(JButton Cikis) {
        this.Cikis = Cikis;
    }
}
