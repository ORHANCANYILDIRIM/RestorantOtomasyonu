
package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.KullaniciAction;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class KullaniciGUI extends JFrame{
    private JButton Siparisver;
    private JButton Rezervasyon;
    private JButton Cikis;
   
    public KullaniciGUI() {
       initJFrame();    
    }

    private void initJFrame(){
        add(initPanel());
        setTitle("Kullanici Sayfasi");
        setLocationRelativeTo(null);
        setBounds(450, 250, 850, 450);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    
    private JPanel initPanel(){
        JPanel KullaniciPanel =new JPanel();
        KullaniciPanel.setBackground(new Color(255,240,255));
        KullaniciPanel.setLayout(null);
        
        KullaniciPanel.add(getSiparisver());
        KullaniciPanel.add(getRezervasyon());
        KullaniciPanel.add(getCikis());
        
        
        
        return KullaniciPanel;
    }
    
    public JButton getSiparisver() {
        if(Siparisver==null){
            Siparisver=new JButton("Siparisver");
            Siparisver.setBounds(175, 50, 200, 170);
            Siparisver.setBackground(new Color(143,194,197));
            Siparisver.addActionListener(new KullaniciAction(this));
        }
        return Siparisver;
    }

    public void setSiparisver(JButton Siparisver) {
        this.Siparisver = Siparisver;
    }

    public JButton getRezervasyon() {
        if(Rezervasyon==null){
            Rezervasyon=new JButton("Rezervasyon");
            Rezervasyon.setBounds(425, 50, 200, 170);
            Rezervasyon.setBackground(new Color(143,194,197));
        }
        return Rezervasyon;
    }

    public void setRezervasyon(JButton Rezervasyon) {
        this.Rezervasyon = Rezervasyon;
    }

    public JButton getCikis() {
        if(Cikis==null){
            Cikis=new JButton("Cikis");
            Cikis.setBounds(625, 300, 100, 30);
            Cikis.setBackground(new Color(186,153,187));
            Cikis.addActionListener(new KullaniciAction(this));
        }            
        return Cikis;
    }

    public void setCikis(JButton Cikis) {
        this.Cikis = Cikis;
    }
}
