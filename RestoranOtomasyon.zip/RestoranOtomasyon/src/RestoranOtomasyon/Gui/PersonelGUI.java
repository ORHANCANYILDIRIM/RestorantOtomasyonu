
package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.PersonelAction;
import RestoranOtomasyon.DAO.PersonelDAO;
import RestoranOtomasyon.Entitiy.Personel;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PersonelGUI extends JFrame{
    private JTable personelTablo;
    private JLabel AdSoyad;
    private JLabel Gorev;
    private JLabel Maas;
    private JLabel ID;
    private JTextField AdSoyadF;
    private JTextField MaasF;
    private JTextField GorevF;
    private JTextField IDF;
    private JScrollPane tabloPane;
    private JButton Ekle;
    private JButton GeriDon;
    private JButton Sil;
    private DefaultTableModel personelmodel;
    public Object[] personelVeri;   
    
    public PersonelGUI() throws IOException {
       PersonelDAO personeldao =new PersonelDAO();
        
       personelmodel = new DefaultTableModel();
       Object[] personelObje = new Object[4];
       
       personelObje[0] = "ID";
       personelObje[1] = "Ad Soyad";
       personelObje[2] = "Gorev";
       personelObje[3] = "Maas";

       personelmodel.setColumnIdentifiers(personelObje);
       personelVeri = new Object[4];
       
       List<Personel> pList = personeldao.getList();

        for (int i = 0; i < pList.size(); i++) {
            personelVeri[0] = pList.get(i).getID();
            personelVeri[1] = pList.get(i).getIsimSoyisım();
            personelVeri[2] = pList.get(i).getGorev();
            personelVeri[3] = pList.get(i).getMaas();

            this.personelmodel.addRow(personelVeri); 
        }
       initJFrame();    
    }
    
    public void PersonelModelGuncelle() throws IOException {
        DefaultTableModel clearModel = personelmodel;
        clearModel.setRowCount(0);
        PersonelDAO personelDAO = new PersonelDAO();
        
        List<Personel> PList = personelDAO.getList();
        for (int i = 0; i < PList.size(); i++) {
            personelVeri[0] = PList.get(i).getID();
            personelVeri[1] = PList.get(i).getIsimSoyisım();
            personelVeri[2] = PList.get(i).getGorev();
            personelVeri[3] = PList.get(i).getMaas();

            this.personelmodel.addRow(personelVeri);

        }

    }

    private void initJFrame(){
        add(initPanel());
        setTitle("Personel Sayfasi");
        setLocationRelativeTo(null);
        setBounds(450, 200, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel PersonelPanel =new JPanel();
        PersonelPanel.setLayout(null);

        PersonelPanel.add(getTabloPane());
        PersonelPanel.add(getAdSoyad());
        PersonelPanel.add(getAdSoyadF());
        PersonelPanel.add(getGorev());
        PersonelPanel.add(getGorevF());
        PersonelPanel.add(getMaas());
        PersonelPanel.add(getMaasF());
        PersonelPanel.add(getEkle());
        PersonelPanel.add(getGeriDon());
        PersonelPanel.add(getID());
        PersonelPanel.add(getIDF());
        PersonelPanel.add(getSil());
        
        return PersonelPanel;
    }

    public JTable getPersonelTable() {
        if(personelTablo==null){
           personelTablo=new JTable();
           personelTablo.setModel(personelmodel);
        }
        return personelTablo;
    }

    public void setPersonelTable(JTable personelTable) {
        this.personelTablo = personelTable;
    }


    public JLabel getAdSoyad() {
        if(AdSoyad==null){
            AdSoyad=new JLabel("Ad Soyad :");
            AdSoyad.setBounds(50, 100, 200, 50);
            AdSoyad.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return AdSoyad;
    }

    public void setAdSoyad(JLabel AdSoyad) {
        this.AdSoyad = AdSoyad;
    }

    public JLabel getGorev() {
        if(Gorev==null){
            Gorev=new JLabel("Gorev :");
            Gorev.setBounds(50, 180, 200, 50);
            Gorev.setFont(new Font("Times New Roman", Font.PLAIN, 20));           
        }
        return Gorev;
    }

    public void setGorev(JLabel Gorev) {
        this.Gorev = Gorev;
    }

    public JLabel getMaas() {
        if(Maas==null){
            Maas=new JLabel("Maas :");
            Maas.setBounds(50, 260, 200, 50);
            Maas.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Maas;
    }

    public void setMaas(JLabel Maas) {
        this.Maas = Maas;
    }

     public JTextField getAdSoyadF() {
        if(AdSoyadF==null){
           AdSoyadF=new JTextField();
           AdSoyadF.setBounds(50, 150, 200, 30);
        }
        return AdSoyadF;
    }

    public void setAdSoyadF(JTextField AdSoyadF) {
        this.AdSoyadF = AdSoyadF;
    }

    public JTextField getMaasF() {
        if(MaasF==null){
           MaasF=new JTextField();
           MaasF.setBounds(50, 310, 200, 30);
        }
        return MaasF;
    }

    public void setMaasF(JTextField MaasF) {
        this.MaasF = MaasF;
    }

    public JTextField getGorevF() {
        if(GorevF==null){
           GorevF=new JTextField();
           GorevF.setBounds(50, 230, 200, 30);
        }
        return GorevF;
    }

    public void setGorevF(JTextField GorevF) {
        this.GorevF = GorevF;
    }
    
    public JScrollPane getTabloPane() {
        if(tabloPane==null){
            tabloPane=new JScrollPane();
            tabloPane.setViewportView(getPersonelTable());
            tabloPane.setBounds(450, 110, 500, 400);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }
    
    public JButton getEkle() {
        if(Ekle==null){
            Ekle=new JButton("Ekle");
            Ekle.setBounds(50, 360, 200, 30);
            Ekle.addActionListener(new PersonelAction(this));
        }
        return Ekle;
    }

    public void setEkle(JButton Ekle) {
        this.Ekle = Ekle;
    }
    
    public JButton getGeriDon() {
        if(GeriDon==null){
            GeriDon=new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.addActionListener(new PersonelAction(this));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }
    
     public JLabel getID() {
        if(ID==null){
           ID=new JLabel("ID :");
           ID.setBounds(50, 410, 100, 30);
           ID.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        } 
        return ID;
    }

    public void setID(JLabel ID) {
        this.ID = ID;
    }

    public JTextField getIDF() {
        if(IDF==null){
           IDF=new JTextField();
           IDF.setBounds(50, 450, 200, 30);
        } 
        return IDF;
    }

    public void setIDF(JTextField IDF) {
        this.IDF = IDF;
    }
       
    public JButton getSil() {
        if(Sil==null){
           Sil=new JButton("Sil");
           Sil.setBounds(50, 500, 200, 30);
        } 
        return Sil;
    }

    public void setSil(JButton Sil) {
        this.Sil = Sil;
    }
  
}
