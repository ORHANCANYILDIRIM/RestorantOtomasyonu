
package RestoranOtomasyon.Gui;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MasaGUI extends JFrame{
    private JPanel MasaPanel;
    
    
    public MasaGUI() {
        initJFrame();
    }
    
    
    
    private void initJFrame(){
        add(initPanel());
        setTitle("Admin Sayfasi");
        setLocationRelativeTo(null);
        setBounds(600, 250,750,550);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        MasaPanel=new JPanel();
        
        return MasaPanel; 
    }
}
