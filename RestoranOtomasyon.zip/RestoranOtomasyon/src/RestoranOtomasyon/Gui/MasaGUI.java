package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.MasaAction;
import RestoranOtomasyon.DAO.MasaDAO;
import RestoranOtomasyon.Entitiy.Masa;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class MasaGUI extends JFrame{
    private JTable MasaTablo;
    private JButton GeriDon;
    private JButton Ekle;
    private JButton Çıkart;
    private JLabel ID;
    private JLabel Doluluk;
    private JComboBox DolulukF;
    private JTextField CikarmaID;
    private JScrollPane tabloPane;
    private DefaultTableModel Masamodel;
    public Object[] masaVeri;
    
    public MasaGUI() throws IOException {
        MasaDAO masadao =new MasaDAO();
        
        Masamodel = new DefaultTableModel();
        Object[] personelObje = new Object[2];
       
        personelObje[0] = "ID";
        personelObje[1] = "Doluluk";
      

        Masamodel.setColumnIdentifiers(personelObje);
        masaVeri = new Object[2];
       
        List<Masa> mList = masadao.getList();

        for (int i = 0; i < mList.size(); i++) {
            masaVeri[0] = mList.get(i).getID();
            masaVeri[1] = mList.get(i).getDoluluk();
           

            this.Masamodel.addRow(masaVeri); 
        }
       initJFrame();    
    }
    
    public void MasaModelGuncelle() throws IOException {
        DefaultTableModel clearModel = Masamodel;
        clearModel.setRowCount(0);
        MasaDAO masadao = new MasaDAO();
        
        List<Masa> MList = masadao.getList();
        for (int i = 0; i < MList.size(); i++) {
            masaVeri[0] = MList.get(i).getID();
            masaVeri[1] = MList.get(i).getDoluluk();
            
            this.Masamodel.addRow(masaVeri);

        }
    }
    
    private void initJFrame(){
        add(initPanel());
        setTitle("Masa Sayfasi");
        setLocationRelativeTo(null);
        setBounds(600, 250,700,500);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        JPanel MasaPanel=new JPanel();
        MasaPanel.setBackground(new Color(255,240,255));
        MasaPanel.setLayout(null);
        
        MasaPanel.add(getGeriDon());
        MasaPanel.add(getID());
        MasaPanel.add(getÇıkart());
        MasaPanel.add(getTabloPane());
        MasaPanel.add(getEkle());
        MasaPanel.add(getCikarmaID());
        MasaPanel.add(getDoluluk());
        MasaPanel.add(getDolulukF());
        MasaPanel.add(getEkle());
        
        return MasaPanel; 
    }

    public JButton getGeriDon() {
        if(GeriDon==null){
            GeriDon=new JButton("Geri Don");
            GeriDon.setBounds(560, 410, 100, 30);
            GeriDon.setBackground(new Color(186,153,187));
            GeriDon.addActionListener(new MasaAction(this));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }

    public JButton getEkle() {
        if(Ekle==null){
            Ekle=new JButton("Masa Ekle");
            Ekle.setBounds(100, 410, 150, 30);
            Ekle.setBackground(new Color(143,194,197));
            Ekle.addActionListener(new MasaAction(this));
        }
        return Ekle;
    }

    public void setEkle(JButton Ekle) {
        this.Ekle = Ekle;
    }

    public JButton getÇıkart() {
        if(Çıkart==null){
            Çıkart=new JButton("Masa Cıkart");
            Çıkart.setBounds(350, 410, 150, 30);
            Çıkart.setBackground(new Color(143,194,197));
            Çıkart.addActionListener(new MasaAction(this));
        }
        return Çıkart;
    }

    public void setÇıkart(JButton Çıkart) {
        this.Çıkart = Çıkart;
    }

    public JLabel getID() {
        if(ID==null){
            ID=new JLabel("ID :");
            ID.setBounds(350, 330, 150, 40);
            ID.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return ID;
    }

    public void setID(JLabel ID) {
        this.ID = ID;
    }

    public JTable getMasaTablo() {
         if(MasaTablo==null){
           MasaTablo=new JTable();
           MasaTablo.setModel(Masamodel);
        }
        return MasaTablo;
    }

    public void setMasaTablo(JTable MasaTablo) {
        this.MasaTablo = MasaTablo;
    }

    public JScrollPane getTabloPane() {
        if(tabloPane==null){
            tabloPane=new JScrollPane();
            tabloPane.setViewportView(getMasaTablo());
            tabloPane.setBounds(100, 30, 500, 300);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }

    public JLabel getDoluluk() {
        if(Doluluk ==null){
            Doluluk=new JLabel("Doluluk giriniz: ");
            Doluluk.setBounds(100, 340, 150, 30);
            Doluluk.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Doluluk;
    }

    public void setDoluluk(JLabel Doluluk) {
        this.Doluluk = Doluluk;
    }

    public JComboBox getDolulukF() {
        if(DolulukF==null){
            String dizi[]={"Dolu","Bos"};
            DolulukF=new JComboBox(dizi);
            DolulukF.setBounds(100, 370, 150, 30);
        }
        return DolulukF;
    }

    public void setDolulukF(JComboBox DolulukF) {
        this.DolulukF = DolulukF;
    }

    public JTextField getCikarmaID() {
        if(CikarmaID==null){
            CikarmaID=new JTextField();
            CikarmaID.setBounds(350, 370, 150, 30);
        }
        return CikarmaID;
    }

    public void setCikarmaID(JTextField CikarmaID) {
        this.CikarmaID = CikarmaID;
    }
  
    
}
