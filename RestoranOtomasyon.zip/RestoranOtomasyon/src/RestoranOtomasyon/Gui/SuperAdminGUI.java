
package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.SuperAdminAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SuperAdminGUI extends JFrame{
    private JButton Masa;
    private JButton Rezervasyon;
    private JButton Mutfak;
    private JButton Müsteriler;
    private JButton PaketServis;
    private JButton Personel;
    private JButton Cikis;
   
    public SuperAdminGUI() {
       initJFrame();    
    }

    private void initJFrame(){
        add(initPanel());
        setTitle("Admin Sayfasi");
        setLocationRelativeTo(null);
        setBounds(500, 250,950,550);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel SuperAdminPanel =new JPanel();
        SuperAdminPanel.setLayout(null);
        
        SuperAdminPanel.add(getMasa());
        SuperAdminPanel.add(getMutfak());
        SuperAdminPanel.add(getMüsteriler());
        SuperAdminPanel.add(getRezervasyon());
        SuperAdminPanel.add(getPaketServis());
        SuperAdminPanel.add(getPersonel());
        SuperAdminPanel.add(getCikis());
        
        
        
        return SuperAdminPanel;
    }
    
    public JButton getMasa() {
        if(Masa==null){
            Masa=new JButton("Masa");
            Masa.setBounds(100, 50, 200, 170);
            Masa.addActionListener(new SuperAdminAction(this));
        }
        return Masa;
    }

    public void setMasa(JButton Masa) {
        this.Masa = Masa;
    }

    public JButton getRezervasyon() {
        if(Rezervasyon==null){
            Rezervasyon=new JButton("Rezervasyon");
            Rezervasyon.setBounds(350, 50, 200, 170);
        }
        return Rezervasyon;
    }

    public void setRezervasyon(JButton Rezervasyon) {
        this.Rezervasyon = Rezervasyon;
    }

    public JButton getMutfak() {
        if(Mutfak==null){
            Mutfak=new JButton("Mutfak");
            Mutfak.setBounds(600, 50, 200, 170);
            Mutfak.addActionListener(new SuperAdminAction(this));
        }
        return Mutfak;
    }

    public void setMutfak(JButton Mutfak) {
        this.Mutfak = Mutfak;
    }

    public JButton getMüsteriler() {
        if(Müsteriler==null){
            Müsteriler=new JButton("Müsteriler");
            Müsteriler.setBounds(100, 250, 200, 170);
            Müsteriler.addActionListener(new SuperAdminAction(this));
        }
        return Müsteriler;
    }

    public void setMüsteriler(JButton Müsteriler) {
        this.Müsteriler = Müsteriler;
    }

    public JButton getPaketServis() {
        if(PaketServis==null){
            PaketServis=new JButton("Paket Servis");
            PaketServis.setBounds(350, 250, 200, 170);
        }
        return PaketServis;
    }

    public void setPaketServis(JButton PaketServis) {
        this.PaketServis = PaketServis;
    }

    public JButton getPersonel() {
        if(Personel==null){
            Personel=new JButton("Personel");
            Personel.setBounds(600, 250, 200, 170);
            Personel.addActionListener(new SuperAdminAction(this));
        }
        return Personel;
    }

    public void setPersonel(JButton Personel) {
        this.Personel = Personel;
    }

    public JButton getCikis() {
        if(Cikis==null){
            Cikis=new JButton("Cikis");
            Cikis.setBounds(800, 450, 100, 30);
        }            
        return Cikis;
    }

    public void setCikis(JButton Cikis) {
        this.Cikis = Cikis;
    }
    
}
