package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.KullaniciSiparisAction;
import RestoranOtomasyon.DAO.MutfakDAO;
import RestoranOtomasyon.Entitiy.Mutfak;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class KullaniciSiparisGUI extends JFrame{
    private JScrollPane tabloPane;
    private JTable MenuTablo;
    private JLabel KartNumarasi;
    private JTextField KartNumarasiF;
    private JLabel Kartsahibi;
    private JTextField KartsahibiF;
    private JLabel SKT;
    private JTextField SKTF;
    private JLabel CVV;
    private JTextField CVVF;
    private JButton Öde;
    private JButton Cıkıs;
    private JButton Nakit;
    private JLabel YemekAdi;
    private JLabel Menu;
    private JTextField YemekAdiF;
    private JLabel Tutar;
    private JTextField HesapF;
    private JButton Ekle;
    private DefaultTableModel Mutfakmodel;
    public Object[] mutfakVeri;
    
    public KullaniciSiparisGUI() throws IOException {
        
         MutfakDAO mutfakdao = new MutfakDAO();

        Mutfakmodel = new DefaultTableModel();
        Object[] müsteriObje = new Object[3];

        müsteriObje[0] = "ID";
        müsteriObje[1] = "YemekAdi";
        müsteriObje[2] = "Fiyat";

        Mutfakmodel.setColumnIdentifiers(müsteriObje);
        mutfakVeri = new Object[3];

        List<Mutfak> MList = mutfakdao.getList();

        for (int i = 0; i < MList.size(); i++) {
            mutfakVeri[0] = MList.get(i).getID();
            mutfakVeri[1] = MList.get(i).getYemekAdi();
            mutfakVeri[2] = MList.get(i).getFiyat();
            

            this.Mutfakmodel.addRow(mutfakVeri);
        }
        
        initJFrame();
       
    }
    
    public void MutfakModelGuncelle() throws IOException {
        DefaultTableModel clearModel = Mutfakmodel;
        clearModel.setRowCount(0);
        MutfakDAO mutfakdao = new MutfakDAO();

        List<Mutfak> mList = mutfakdao.getList();
        for (int i = 0; i < mList.size(); i++) {
            mutfakVeri[0] = mList.get(i).getID();
            mutfakVeri[1] = mList.get(i).getYemekAdi();
            mutfakVeri[2] = mList.get(i).getFiyat();
            

            this.Mutfakmodel.addRow(mutfakVeri);

        }

    }   
    
    private void initJFrame(){
        add(initPanel());
        setTitle("Kullanici Ödeme");
        setBounds(500,500, 800,600);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel OdemePanel =new JPanel();
           OdemePanel.setBackground(new Color(255,240,255));


        OdemePanel.setLayout(null);
        
        OdemePanel.add(getKartNumarasi());
        OdemePanel.add(getKartNumarasiF());
        OdemePanel.add(getKartsahibi());
        OdemePanel.add(getKartsahibiF());
        OdemePanel.add(getSKT());
        OdemePanel.add(getSKTF());
        OdemePanel.add(getCVV());
        OdemePanel.add(getCVVF());
        OdemePanel.add(getÖde());
        OdemePanel.add(getCıkıs());
        OdemePanel.add(getNakit());
        OdemePanel.add(getTabloPane());
        OdemePanel.add(getEkle());
        OdemePanel.add(getYemekAdi());
        OdemePanel.add(getYemekAdiF());
        OdemePanel.add(getMenu());
        OdemePanel.add(getHesapF());
        OdemePanel.add(getTutar());
        
        
        return OdemePanel;
    }
     
    
    
    public JLabel getKartNumarasi() {
        if(KartNumarasi==null){
            this.KartNumarasi=new JLabel("Kart Numarası :");
            KartNumarasi.setBounds(50, 100, 150, 60);
        }
        return KartNumarasi;
    }

    public void setKartNumarasi(JLabel KartNumarasi) {
        this.KartNumarasi = KartNumarasi;
    }

    public JTextField getKartNumarasiF() {
        if(KartNumarasiF==null){
            this.KartNumarasiF=new JTextField();
            KartNumarasiF.setBounds(50, 145, 200, 25);
        }
        return KartNumarasiF;
    }

    public void setKartNumarasiF(JTextField KartNumarasiF) {
        this.KartNumarasiF = KartNumarasiF;
    }
    
    public JLabel getKartsahibi() {
        if(Kartsahibi==null){
            Kartsahibi = new JLabel("Kart Üzerindeki Ad-Soyad:");
            Kartsahibi.setBounds(50, 20, 150, 60);
        }
        return Kartsahibi;
    }

    public void setKartsahibi(JLabel Kartsahibi) {
        this.Kartsahibi = Kartsahibi;
    }

    public JTextField getKartsahibiF() {
        if(KartsahibiF==null){
            KartsahibiF = new JTextField();
            KartsahibiF.setBounds(50, 65, 200, 25);//50, 65, 200, 25
        }
        return KartsahibiF;
    }

    public void setKartsahibiF(JTextField KartsahibiF) {
        this.KartsahibiF = KartsahibiF;
    }
                                                                        
    public JLabel getSKT() {
        if(SKT==null){
            SKT = new JLabel("SKT :");
            SKT.setBounds(50, 190, 40, 25);
        }
        return SKT;
    }

    public void setSKT(JLabel SKT) {
        this.SKT = SKT;
    }

    public JTextField getSKTF() {
        if(SKTF==null){
            SKTF = new JTextField(10);
            SKTF.setBounds(90, 190, 50, 25);
        }
        return SKTF;
    }

    public void setSKTF(JTextField SKTF) {
        this.SKTF = SKTF;
    }
    
     public JLabel getCVV() {
        if(CVV==null){
            CVV= new JLabel("CVV :");
            CVV.setBounds(150, 190, 50, 25);
        }
        return CVV;
    }

    public void setCVV(JLabel CVV) {
        this.CVV = CVV;
    }

    public JTextField getCVVF() {
        if(CVVF==null){
            CVVF = new JTextField(10);
            CVVF.setBounds(200, 190, 50, 25);
        }
        return CVVF;
    }

    public void setCVVF(JTextField CVVF) {
        this.CVVF = CVVF;
    }

    public JButton getÖde() {
        if(Öde==null){
            Öde = new JButton("Öde");
            Öde.setBounds(165, 270, 85, 30);
            Öde.setBackground(new Color(143,194,197));
            Öde.addActionListener(new KullaniciSiparisAction(this));
        }
        return Öde;
    }

    public void setÖde(JButton Öde) {
        this.Öde = Öde;
    }

    public JButton getCıkıs() {
        if(Cıkıs==null){           
            Cıkıs = new JButton("Cıkıs");
            Cıkıs.setBounds(50, 400, 200, 35);
            Cıkıs.setBackground(new Color(186,153,187));
            Cıkıs.addActionListener(new KullaniciSiparisAction(this));
        }
        return Cıkıs;
    }

    public void setCıkıs(JButton Cıkıs) {
        this.Cıkıs = Cıkıs;
    }  
    
     public JButton getNakit() {
        if(Nakit==null){            
            Nakit = new JButton("Nakit Ödemek İstiyorum");
            Nakit.setBackground(Color.lightGray);
            Nakit.setBounds(50, 335, 200, 35);
            Nakit.addActionListener(new KullaniciSiparisAction(this));
        }
        return Nakit;
    }

    public void setNakit(JButton Nakit) {
        this.Nakit = Nakit;
    }  

    public JLabel getYemekAdi() {
        if(YemekAdi==null){
            YemekAdi=new JLabel("Yemek Adi:");
            YemekAdi.setBounds(300, 450, 150, 25);
            YemekAdi.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return YemekAdi;
    }

    public void setYemekAdi(JLabel YemekAdi) {
        this.YemekAdi = YemekAdi;
    }

    public JTextField getYemekAdiF() {
        if(YemekAdiF==null){
            YemekAdiF=new JTextField();
            YemekAdiF.setBounds(300, 480, 150, 25);
        }
        return YemekAdiF;
    }

    public void setYemekAdiF(JTextField YemekAdiF) {
        this.YemekAdiF = YemekAdiF;
    }

    public JButton getEkle() {
        if(Ekle==null){
            Ekle=new JButton("Hesaba ekle");
            Ekle.setBounds(300, 520, 150, 25);
            Ekle.setBackground(new Color(143,194,197));
        }
        return Ekle;
    }

    public void setEkle(JButton Ekle) {
        this.Ekle = Ekle;
    }

    public JScrollPane getTabloPane() {
        if (tabloPane == null) {
            tabloPane = new JScrollPane();
            tabloPane.setViewportView(getMenuTablo());
            tabloPane.setBounds(300, 40, 450, 400);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }

    public JTable getMenuTablo() {
        if (MenuTablo == null) {
            MenuTablo = new JTable();
            MenuTablo.setModel(Mutfakmodel);
        }
        return MenuTablo;
    }

    public void setMenuTablo(JTable MenuTablo) {
        this.MenuTablo = MenuTablo;
    }

    public JLabel getMenu() {
        if(Menu==null){
            Menu=new JLabel("Menu");
            Menu.setBounds(500, 10 , 100, 30);
            Menu.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        }
        return Menu;
    }

    public void setMenu(JLabel Menu) {
        this.Menu = Menu;
    }

    public JTextField getHesapF() {
        if(HesapF==null){
            HesapF=new JTextField();
            HesapF.setBounds(500, 480 , 150, 25);
        }
        return HesapF;
    }

    public void setHesapF(JTextField HesapF) {
        this.HesapF = HesapF;
    }

    public JLabel getTutar() {
        if(Tutar==null){
            Tutar=new JLabel("Tutar :");
            Tutar.setBounds(500, 450 , 150, 25);
            Tutar.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Tutar;
    }

    public void setTutar(JLabel Tutar) {
        this.Tutar = Tutar;
    }
    
    
    
}
