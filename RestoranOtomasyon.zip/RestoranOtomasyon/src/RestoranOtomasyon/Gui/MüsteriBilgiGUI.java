package RestoranOtomasyon.Gui;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MüsteriBilgiGUI extends JFrame {

    public MüsteriBilgiGUI() {
    }

    public void initJFrame() {
        add(initPanel());
        setTitle("Müsteri Bilgileri Sayfasi");
        setLocationRelativeTo(null);
        setBounds(500, 250, 950, 550);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    public JPanel initPanel() {
        JPanel MüsteriBilgiPanel = new JPanel();
        MüsteriBilgiPanel.setBackground(new Color(255,240,255));
        MüsteriBilgiPanel.setLayout(null);
        
        
        
        return MüsteriBilgiPanel;
    }
}
