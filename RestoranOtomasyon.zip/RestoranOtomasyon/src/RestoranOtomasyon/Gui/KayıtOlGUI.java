
package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.KayıtOlAction;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class KayıtOlGUI extends JFrame{
    private JLabel IsımSoyısım;
    private JTextField IsımSoyısımF;
    private JLabel KullaniciAdi;
    private JTextField KullaniciAdiF;
    private JLabel Parola;
    private JPasswordField ParolaF;
    private JLabel ParolaYeni;
    private JPasswordField ParolaYeniF;
    private JButton KayıtOl;
    private JButton Cıkıs;

   

    public KayıtOlGUI() {
        initJFrame();
    }
    
    private void initJFrame(){
        add(initPanel());
        setTitle("Kullanici Kayıt");
        setBounds(500,500, 400,400);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel KayıtOlPanel =new JPanel();
        KayıtOlPanel.setBackground(new Color(255,240,255));
        KayıtOlPanel.setLayout(null);
        
        KayıtOlPanel.add(getIsımSoyısım());
        KayıtOlPanel.add(getIsımSoyısımF());
        KayıtOlPanel.add(getKullaniciAdi());
        KayıtOlPanel.add(getKullaniciAdiF());
        KayıtOlPanel.add(getParola());
        KayıtOlPanel.add(getParolaF());
        KayıtOlPanel.add(getParolaYeni());
        KayıtOlPanel.add(getParolaYeniF());
        KayıtOlPanel.add(getKayıtOl());
        KayıtOlPanel.add(getCıkıs());
         
        return KayıtOlPanel;
    }
     
    
    
    public JLabel getIsımSoyısım() {
        if(IsımSoyısım==null){
            this.IsımSoyısım=new JLabel("Isim Soyisim :");
            IsımSoyısım.setBounds(50, 20, 100, 60);
        }
        return IsımSoyısım;
    }

    public void setIsımSoyısım(JLabel IsımSoyısım) {
        this.IsımSoyısım = IsımSoyısım;
    }

    public JTextField getIsımSoyısımF() {
        if(IsımSoyısımF==null){
            this.IsımSoyısımF=new JTextField();
            IsımSoyısımF.setBounds(175, 40, 150, 25);
        }
        return IsımSoyısımF;
    }

    public void setIsımSoyısımF(JTextField IsımSoyısımF) {
        this.IsımSoyısımF = IsımSoyısımF;
    }
    
    public JLabel getKullaniciAdi() {
        if(KullaniciAdi==null){
            KullaniciAdi = new JLabel("Kullanıcı Adı :");
            KullaniciAdi.setBounds(50, 70, 100, 60);
        }
        return KullaniciAdi;
    }

    public void setKullaniciAdi(JLabel KullaniciAdi) {
        this.KullaniciAdi = KullaniciAdi;
    }

    public JTextField getKullaniciAdiF() {
        if(KullaniciAdiF==null){
            KullaniciAdiF = new JTextField();
            KullaniciAdiF.setBounds(175, 90, 150, 25);
        }
        return KullaniciAdiF;
    }

    public void setKullaniciAdiF(JTextField KullaniciAdiF) {
        this.KullaniciAdiF = KullaniciAdiF;
    }

    public JLabel getParola() {
        if(Parola==null){
            Parola = new JLabel("Parola :");
            Parola.setBounds(50, 120, 100, 60);
        }
        return Parola;
    }

    public void setParola(JLabel Parola) {
        this.Parola = Parola;
    }

    public JTextField getParolaF() {
        if(ParolaF==null){
            ParolaF = new JPasswordField(10);
            ParolaF.setBounds(175, 140, 150, 25);
        }
        return ParolaF;
    }

    public void setParolaF(JPasswordField ParolaF) {
        this.ParolaF = ParolaF;
    }
    
     public JLabel getParolaYeni() {
        if(ParolaYeni==null){
            ParolaYeni= new JLabel("Parola Yeniden :");
            ParolaYeni.setBounds(50, 170, 100, 60);
        }
        return ParolaYeni;
    }

    public void setParolaYeni(JLabel ParolaYeni) {
        this.ParolaYeni = ParolaYeni;
    }

    public JPasswordField getParolaYeniF() {
        if(ParolaYeniF==null){
            ParolaYeniF = new JPasswordField(10);
            ParolaYeniF.setBounds(175, 190, 150, 25);
        }
        return ParolaYeniF;
    }

    public void setParolaYeniF(JPasswordField ParolaYeniF) {
        this.ParolaYeniF = ParolaYeniF;
    }

    public JButton getKayıtOl() {
        if(KayıtOl==null){
            KayıtOl = new JButton("KayıtOl");
            KayıtOl.setBounds(225, 300, 100, 30);
            KayıtOl.setBackground(new Color(143,194,197));
            KayıtOl.addActionListener(new KayıtOlAction(this));
        }
        return KayıtOl;
    }

    public void setKayıtOl(JButton KayıtOl) {
        this.KayıtOl = KayıtOl;
    }

    public JButton getCıkıs() {
        if(Cıkıs==null){            
            Cıkıs = new JButton("Cikis");
            Cıkıs.setBounds(75, 300, 100, 30);
            Cıkıs.setBackground(new Color(186,153,187));
        }
        return Cıkıs;
    }

    public void setCıkıs(JButton Cıkıs) {
        this.Cıkıs = Cıkıs;
    }      
}
