package RestoranOtomasyon.Gui;


import RestoranOtomasyon.Action.SecimAction;


import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

public class SecimGUI extends JDialog{
    private JButton Admin; 
    private JButton Kullanici;

    public SecimGUI() {
        initJDialog();
    }
    
    private void initJDialog(){
        add(initPanel());
        setTitle("Kullanici Girisi");
        setLocationRelativeTo(null);
        pack();
        setBounds(800, 350, 300, 300);
        setVisible(true);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel SecimPanel =new JPanel();
        SecimPanel.setLayout(null);
        
        SecimPanel.add(getAdmin());
        SecimPanel.add(getKullanici());
        
        return SecimPanel;
    }

    public JButton getAdmin() {
        if(Admin == null){
            Admin = new JButton("Admin Girisi");
            Admin.setBounds(70,50, 150, 40);
            Admin.addActionListener( new SecimAction(this));
        }
        return Admin;
    }

    public void setAdmin(JButton Admin) {
        this.Admin = Admin;
    }

    public JButton getKullanici() {
        if(Kullanici==null){
            Kullanici = new JButton("Kullanici Girisi");
            Kullanici.setBounds(70,150, 150, 40);
            Kullanici.addActionListener( new SecimAction(this));
        }
        return Kullanici;
    }

    public void setKullanici(JButton Kullanici) {
        this.Kullanici = Kullanici;
    }
    
}
