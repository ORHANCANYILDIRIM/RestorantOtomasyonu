package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.KullaniciGirisAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class KullaniciGirisGUI extends JFrame {
  
    private JLabel KullaniciAdi;
    private JTextField KullaniciAdiF;
    private JLabel Parola;
    private JPasswordField ParolaF;
    private JButton Giris;
    private JButton Cıkıs;
    private JButton KayitOl;

    public KullaniciGirisGUI() {
       initJFrame();
       
    }
    
    private void initJFrame(){
        add(initPanel());
        setTitle("Kullanici Girisi");
        setBounds(500,500, 400,400);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel GirisPanel =new JPanel();
        GirisPanel.setLayout(null);
        
        GirisPanel.add(getKullaniciAdi());
        GirisPanel.add(getKullaniciAdiF());
        GirisPanel.add(getParola());
        GirisPanel.add(getParolaF());
        GirisPanel.add(getGiris());
        GirisPanel.add(getCıkıs());
        GirisPanel.add(getKayitOl());
   
        return GirisPanel;
    }
     
    
    
    public JLabel getKullaniciAdi() {
        if(this.KullaniciAdi==null){
            KullaniciAdi = new JLabel("Kullanıcı Adı :");
            KullaniciAdi.setBounds(75, 60, 100, 60);
        }
        return KullaniciAdi;
    }

    public void setKullaniciAdi(JLabel KullaniciAdi) {
        this.KullaniciAdi = KullaniciAdi;
    }

    public JTextField getKullaniciAdiF() {
        if(this.KullaniciAdiF==null){
            KullaniciAdiF = new JTextField();
            KullaniciAdiF.setBounds(200, 75, 150, 30);
        }
        return KullaniciAdiF;
    }

    public void setKullaniciAdiF(JTextField KullaniciAdiF) {
        this.KullaniciAdiF = KullaniciAdiF;
    }

    public JLabel getParola() {
        if(this.Parola==null){
            Parola = new JLabel("Parola :");
            Parola.setBounds(75, 170, 100, 60);
        }
        return Parola;
    }

    public void setParola(JLabel Parola) {
        this.Parola = Parola;
    }

    public JTextField getParolaF() {
        if(this.ParolaF==null){
            ParolaF = new JPasswordField(10);
            ParolaF.setBounds(200, 185, 150, 30);
        }
        return ParolaF;
    }

    public void setParolaF(JPasswordField ParolaF) {
        this.ParolaF = ParolaF;
    }

    public JButton getGiris() {
        if(this.Giris==null){
            Giris = new JButton("Giris");
            Giris.setBounds(225, 270, 100, 30);
            this.Giris.addActionListener(new KullaniciGirisAction(this));
        }
        return Giris;
    }

    public void setGiris(JButton Giris) {
        this.Giris = Giris;
    }

    public JButton getCıkıs() {
        if(this.Cıkıs==null){            
            Cıkıs = new JButton("Cikis");
            Cıkıs.setBounds(75, 270, 100, 30);
        }
        return Cıkıs;
    }

    public void setCıkıs(JButton Cıkıs) {
        this.Cıkıs = Cıkıs;
    }   
     
    public JButton getKayitOl() {
        if(this.KayitOl==null){            
            KayitOl = new JButton("KayitOl");
            KayitOl.setBounds(150, 320, 100, 30);
            this.KayitOl.addActionListener(new KullaniciGirisAction(this));
        }
        return KayitOl;
    }

    public void setKayitOl(JButton KayitOl) {
        this.KayitOl = KayitOl;
    }
    
}
