
package RestoranOtomasyon.Gui;

import RestoranOtomasyon.Action.MüsteriAction;
import RestoranOtomasyon.DAO.KullaniciDAO;
import RestoranOtomasyon.Entitiy.Kullanici;
import RestoranOtomasyon.Entitiy.Mutfak;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class MutfakGUI extends JFrame{
    private JTable MutfakTablo;
    private JLabel Fiyat;
    private JLabel YemekAdi;
    private JLabel Siparis;
    private JLabel ID;
    private JTextField FiyatF;
    private JTextField YemekAdiF;
    private JTextField SiparisF;
    private JTextField IDF;
    private JScrollPane tabloPane;
    private JButton SiparisEt;
    private JButton GeriDon;
    private JButton Sil;
    private DefaultTableModel Mutfakmodel;
    public Object[] mutfakVeri;   
    
    public MutfakGUI() throws IOException {
       KullaniciDAO kullanicidao =new KullaniciDAO();
        
       Mutfakmodel = new DefaultTableModel();
       Object[] müsteriObje = new Object[4];
       
       müsteriObje[0] = "ID";
       müsteriObje[1] = "Ad Soyad";
       müsteriObje[2] = "Gorev";
       müsteriObje[3] = "Maas";

       Mutfakmodel.setColumnIdentifiers(müsteriObje);
       mutfakVeri = new Object[4];
       
       List<Mutfak> MList = kullanicidao.getList2();

        for (int i = 0; i < MList.size(); i++) {
            mutfakVeri[0] = MList.get(i).getID();
            mutfakVeri[1] = MList.get(i).getYemekAdi();
            mutfakVeri[2] = MList.get(i).getStokDurum();
            mutfakVeri[3] = MList.get(i).getFiyat();

            this.Mutfakmodel.addRow(mutfakVeri); 
        }
       initJFrame();    
    }
    
    public void MutfakModelGuncelle() throws IOException {
        DefaultTableModel clearModel = Mutfakmodel;
        clearModel.setRowCount(0);
        KullaniciDAO kullanicidao = new KullaniciDAO();
        
        List<Mutfak> mList = kullanicidao.getList2();
        for (int i = 0; i < mList.size(); i++) {
            mutfakVeri[0] = mList.get(i).getID();
            mutfakVeri[1] = mList.get(i).getYemekAdi();
            mutfakVeri[2] = mList.get(i).getStokDurum();
            mutfakVeri[3] = mList.get(i).getFiyat();

            this.Mutfakmodel.addRow(mutfakVeri);

        }

    }

    private void initJFrame(){
        add(initPanel());
        setTitle("Müsteri Sayfasi");
        setLocationRelativeTo(null);
        setBounds(450, 200, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel initPanel(){
        JPanel MutfakPanel =new JPanel();
        MutfakPanel.setLayout(null);

        MutfakPanel.add(getTabloPane());
        MutfakPanel.add(getFiyat());
        MutfakPanel.add(getFiyatF());
        MutfakPanel.add(getYemekAdi());
        MutfakPanel.add(getYemekAdiF());
        MutfakPanel.add(getSiparis());
        MutfakPanel.add(getSiparisF());
        MutfakPanel.add(getSiparisEt());
        MutfakPanel.add(getGeriDon());
        MutfakPanel.add(getID());
        MutfakPanel.add(getIDF());
        MutfakPanel.add(getSil());
        
        return MutfakPanel;
    }
     public JTable getMutfakTablo() {
        if(MutfakTablo==null){
           MutfakTablo=new JTable();
           MutfakTablo.setModel(Mutfakmodel);
        }
        return MutfakTablo;
    }

    public void setMüsteriTablo(JTable MüsteriTablo) {
        this.MutfakTablo = MüsteriTablo;
    }


    public JLabel getFiyat() {
        if(Fiyat==null){
            Fiyat=new JLabel("Fiyat :");
            Fiyat.setBounds(50, 260, 200, 50);
            Fiyat.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Fiyat;
    }

    public void setId(JLabel Fiyat) {
        this.Fiyat = Fiyat;
    }

    public JLabel getYemekAdi() {
        if(YemekAdi==null){
            YemekAdi=new JLabel("Yemek Adi:");
            YemekAdi.setBounds(50, 100, 200, 50);
            YemekAdi.setFont(new Font("Times New Roman", Font.PLAIN, 20));           
        }
        return YemekAdi;
    }

    public void setYemekAdi(JLabel YemekAdi) {
        this.YemekAdi = YemekAdi;
    }

    public JLabel getSiparis() {
        if(Siparis==null){
            Siparis=new JLabel("Siparis miktarı :");
            Siparis.setBounds(50, 180, 200, 50);
            Siparis.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Siparis;
    }

    public void setSiparis(JLabel Siparis) {
        this.Siparis= Siparis;
    }

     public JTextField getFiyatF() {
        if(FiyatF==null){
           FiyatF=new JTextField();
           FiyatF.setBounds(50, 150, 200, 30);
        }
        return FiyatF;
    }

    public void setFiyatF(JTextField FiyatF) {
        this.FiyatF = FiyatF;
    }

    public JTextField getSiparisF() {
        if(SiparisF==null){
           SiparisF=new JTextField();
           SiparisF.setBounds(50, 310, 200, 30);
        }
        return SiparisF;
    }

    public void setSifreF(JTextField SiparisF) {
        this.SiparisF = SiparisF;
    }

    public JTextField getYemekAdiF() {
        if(YemekAdiF==null){
           YemekAdiF=new JTextField();
           YemekAdiF.setBounds(50, 230, 200, 30);
        }
        return YemekAdiF;
    }

    public void setKullaniciAdiF(JTextField YemekAdiF) {
        this.YemekAdiF = YemekAdiF;
    }
    
    public JScrollPane getTabloPane() {
        if(tabloPane==null){
            tabloPane=new JScrollPane();
            tabloPane.setViewportView(getMutfakTablo());
            tabloPane.setBounds(450, 110, 500, 400);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }
    
    public JButton getSiparisEt() {
        if(SiparisEt==null){
            SiparisEt=new JButton("Ekle");
            SiparisEt.setBounds(50, 360, 200, 30);
            //SiparisEt.addActionListener(new MüsteriAction(this));
        }
        return SiparisEt;
    }

    public void setSiparisEt(JButton SiparisEt) {
        this.SiparisEt = SiparisEt;
    }
    
    public JButton getGeriDon() {
        if(GeriDon==null){
            GeriDon=new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            //GeriDon.addActionListener(new MüsteriAction(this));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }
    
     public JLabel getID() {
        if(ID==null){
           ID=new JLabel("ID :");
           ID.setBounds(50, 410, 100, 30);
           ID.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        } 
        return ID;
    }

    public void setID(JLabel ID) {
        this.ID = ID;
    }

    public JTextField getIDF() {
        if(IDF==null){
           IDF=new JTextField();
           IDF.setBounds(50, 450, 200, 30);
        } 
        return IDF;
    }

    public void setIDF(JTextField IDF) {
        this.IDF = IDF;
    }
       
    public JButton getSil() {
        if(Sil==null){
           Sil=new JButton("Sil");
           Sil.setBounds(50, 500, 200, 30);
        } 
        return Sil;
    }

    public void setSil(JButton Sil) {
        this.Sil = Sil;
    }
  
    
}
